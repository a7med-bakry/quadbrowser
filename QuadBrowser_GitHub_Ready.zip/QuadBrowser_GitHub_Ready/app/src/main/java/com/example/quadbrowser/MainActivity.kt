package com.example.quadbrowser

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val browsers = ArrayList<WebView>()

    private lateinit var drawer: FrameLayout
    private lateinit var drawerDim: View
    private lateinit var hamburger: TextView
    private lateinit var statusText: TextView
    private lateinit var countdownText: TextView
    private lateinit var startTimeInput: EditText
    private lateinit var nowCheck: CheckBox
    private lateinit var refreshInput: EditText
    private lateinit var startButton: Button
    private lateinit var stopButton: Button

    private val linkInputs = ArrayList<EditText>()
    private val durationInputs = ArrayList<EditText>()

    private var scheduleRunning = false
    private var scheduleStartMs = 0L
    private var urls = emptyList<String>()
    private var durationsMs = emptyList<Long>()
    private var currentIndex = -1
    private var refreshSeconds = 30L

    private val scheduleTask = object : Runnable {
        override fun run() {
            if (!scheduleRunning) return

            val now = System.currentTimeMillis()
            if (now < scheduleStartMs) {
                countdownText.text = "Starts in ${formatDuration(scheduleStartMs - now)}"
                handler.postDelayed(this, 1000L)
                return
            }

            var elapsed = now - scheduleStartMs
            var index = 0
            while (index < durationsMs.size && elapsed >= durationsMs[index]) {
                elapsed -= durationsMs[index]
                index++
            }

            if (index >= urls.size) {
                finishSchedule()
                return
            }

            if (currentIndex != index) {
                currentIndex = index
                loadUrlInAllPages(urls[index])
                statusText.text = "Link ${index + 1} / ${urls.size}"
            }

            val remaining = durationsMs[index] - elapsed
            countdownText.text = "Link ${index + 1} • ${formatDuration(remaining)}"
            handler.postDelayed(this, 1000L)
        }
    }

    private val refreshTask = object : Runnable {
        override fun run() {
            if (!scheduleRunning) return
            if (refreshSeconds > 0 && currentIndex >= 0) {
                browsers.forEach { it.reload() }
            }
            handler.postDelayed(this, TimeUnit.SECONDS.toMillis(refreshSeconds.coerceAtLeast(1)))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        buildUi()
        restoreSettings()
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        // Portrait layout: 8 WebViews, 2 columns x 4 rows.
        val grid = GridLayout(this).apply {
            columnCount = 2
            rowCount = 4
            setBackgroundColor(Color.BLACK)
            useDefaultMargins = false
        }

        repeat(8) { index ->
            val web = createWebView(index)
            browsers.add(web)

            val cell = FrameLayout(this).apply {
                setBackgroundColor(Color.BLACK)
                setPadding(1.dp(), 1.dp(), 1.dp(), 1.dp())
                addView(web, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                ))
            }

            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = 0
                columnSpec = GridLayout.spec(index % 2, 1, 1f)
                rowSpec = GridLayout.spec(index / 2, 1, 1f)
                setMargins(1.dp(), 1.dp(), 1.dp(), 1.dp())
            }
            grid.addView(cell, params)
        }

        root.addView(grid, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        // Only visible control on the browser screen.
        hamburger = TextView(this).apply {
            text = "☰"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.parseColor("#CC111111"), 14)
            elevation = 12.dp().toFloat()
            setOnClickListener { openDrawer() }
            contentDescription = "Open settings"
        }
        val hamburgerParams = FrameLayout.LayoutParams(54.dp(), 54.dp()).apply {
            gravity = Gravity.TOP or Gravity.START
            topMargin = 8.dp()
            marginStart = 8.dp()
        }
        root.addView(hamburger, hamburgerParams)

        buildDrawer(root)
        setContentView(root)
    }

    private fun buildDrawer(root: FrameLayout) {
        drawerDim = View(this).apply {
            setBackgroundColor(0x99000000.toInt())
            visibility = View.GONE
            setOnClickListener { closeDrawer() }
        }
        root.addView(drawerDim, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        drawer = FrameLayout(this).apply {
            setBackgroundColor(Color.WHITE)
            elevation = 24.dp().toFloat()
            visibility = View.GONE
        }

        val drawerParams = FrameLayout.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.90f).toInt(),
            ViewGroup.LayoutParams.MATCH_PARENT
        ).apply {
            gravity = Gravity.START
        }
        root.addView(drawer, drawerParams)

        val scroll = ScrollView(this)
        drawer.addView(scroll, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16.dp(), 16.dp(), 16.dp(), 28.dp())
        }
        scroll.addView(content)

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "Quad Browser"
            textSize = 23f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(20, 28, 36))
        }
        titleRow.addView(title, LinearLayout.LayoutParams(0, 52.dp(), 1f))

        val close = TextView(this).apply {
            text = "✕"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setOnClickListener { closeDrawer() }
        }
        titleRow.addView(close, LinearLayout.LayoutParams(52.dp(), 52.dp()))
        content.addView(titleRow)

        val subtitle = TextView(this).apply {
            text = "أدخل حتى 10 روابط — كل رابط له مدة مستقلة"
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 0, 0, 12.dp())
        }
        content.addView(subtitle)

        repeat(10) { index ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val number = TextView(this).apply {
                text = "${index + 1}"
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = rounded(Color.rgb(35, 94, 170), 9)
            }
            row.addView(number, LinearLayout.LayoutParams(34.dp(), 46.dp()))

            val url = EditText(this).apply {
                hint = "https://example.com"
                textSize = 13f
                setSingleLine(true)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                setTextColor(Color.rgb(25, 30, 35))
                setHintTextColor(Color.GRAY)
                setPadding(10.dp(), 0, 10.dp(), 0)
                background = roundedBorder()
            }
            linkInputs.add(url)
            row.addView(url, LinearLayout.LayoutParams(0, 46.dp(), 1f).apply {
                marginStart = 7.dp()
            })

            val duration = EditText(this).apply {
                hint = "دقائق"
                text = "90"
                textSize = 12f
                setSingleLine(true)
                gravity = Gravity.CENTER
                inputType = InputType.TYPE_CLASS_NUMBER
                setTextColor(Color.rgb(25, 30, 35))
                setHintTextColor(Color.GRAY)
                setPadding(4.dp(), 0, 4.dp(), 0)
                background = roundedBorder()
            }
            durationInputs.add(duration)
            row.addView(duration, LinearLayout.LayoutParams(70.dp(), 46.dp()).apply {
                marginStart = 7.dp()
            })

            content.addView(row, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 52.dp()
            ))
        }

        content.addView(divider())

        val startLabel = TextView(this).apply {
            text = "بدء التشغيل"
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(30, 35, 40))
        }
        content.addView(startLabel)

        val startRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        startTimeInput = EditText(this).apply {
            hint = "HH:MM"
            text = "13:30"
            textSize = 14f
            setSingleLine(true)
            gravity = Gravity.CENTER
            inputType = InputType.TYPE_CLASS_DATETIME
            setPadding(5.dp(), 0, 5.dp(), 0)
            setTextColor(Color.DKGRAY)
            background = roundedBorder()
        }
        startRow.addView(startTimeInput, LinearLayout.LayoutParams(90.dp(), 48.dp()))

        nowCheck = CheckBox(this).apply {
            text = "NOW"
            textSize = 13f
            isChecked = true
            setOnCheckedChangeListener { _, checked -> startTimeInput.isEnabled = !checked }
        }
        startRow.addView(nowCheck, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, 48.dp()
        ))

        content.addView(startRow)

        val refreshRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val refreshLabel = TextView(this).apply {
            text = "تحديث كل"
            textSize = 14f
            setTextColor(Color.DKGRAY)
        }
        refreshRow.addView(refreshLabel)

        refreshInput = EditText(this).apply {
            setText("30")
            hint = "ثواني"
            textSize = 14f
            gravity = Gravity.CENTER
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.DKGRAY)
            background = roundedBorder()
        }
        refreshRow.addView(refreshInput, LinearLayout.LayoutParams(75.dp(), 48.dp()).apply {
            marginStart = 8.dp()
        })

        val secondsLabel = TextView(this).apply {
            text = "ثانية"
            textSize = 13f
            setTextColor(Color.GRAY)
        }
        refreshRow.addView(secondsLabel, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, 48.dp()
        ).apply { marginStart = 6.dp() })

        content.addView(refreshRow)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        startButton = Button(this).apply {
            text = "START"
            setOnClickListener { startSchedule() }
        }
        stopButton = Button(this).apply {
            text = "STOP"
            isEnabled = false
            setOnClickListener { stopSchedule() }
        }

        buttons.addView(startButton, LinearLayout.LayoutParams(0, 52.dp(), 1f))
        buttons.addView(stopButton, LinearLayout.LayoutParams(0, 52.dp(), 1f).apply {
            marginStart = 8.dp()
        })
        content.addView(buttons, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 60.dp()
        ))

        statusText = TextView(this).apply {
            text = "Ready"
            textSize = 13f
            setTextColor(Color.rgb(35, 94, 170))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        content.addView(statusText)

        countdownText = TextView(this).apply {
            text = "أدخل الروابط واضغط START"
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 5.dp(), 0, 0)
        }
        content.addView(countdownText)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(index: Int): WebView {
        return WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.userAgentString = WebSettings.getDefaultUserAgent(this@MainActivity)

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    view.loadUrl(request.url.toString())
                    return true
                }

                override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    view.contentDescription = "Page ${index + 1}: $url"
                }
            }
            webChromeClient = WebChromeClient()
        }
    }

    private fun startSchedule() {
        val parsed = ArrayList<String>()
        val durations = ArrayList<Long>()

        for (i in 0 until 10) {
            val rawUrl = linkInputs[i].text.toString().trim()
            if (rawUrl.isBlank()) continue

            val mins = durationInputs[i].text.toString().trim().toLongOrNull() ?: 90L
            if (mins < 1) {
                Toast.makeText(this, "مدة الرابط ${i + 1} غير صحيحة", Toast.LENGTH_SHORT).show()
                return
            }

            parsed.add(normalizeUrl(rawUrl))
            durations.add(TimeUnit.MINUTES.toMillis(mins))
        }

        if (parsed.isEmpty()) {
            Toast.makeText(this, "أدخل رابطًا واحدًا على الأقل", Toast.LENGTH_SHORT).show()
            return
        }

        refreshSeconds = refreshInput.text.toString().trim().toLongOrNull() ?: 30L
        if (refreshSeconds < 1) {
            Toast.makeText(this, "التحديث يجب أن يكون ثانية واحدة أو أكثر", Toast.LENGTH_SHORT).show()
            return
        }

        val start = if (nowCheck.isChecked) {
            System.currentTimeMillis()
        } else {
            parseStartTime(startTimeInput.text.toString().trim())
                ?: run {
                    Toast.makeText(this, "اكتب الوقت مثل 13:30", Toast.LENGTH_SHORT).show()
                    return
                }
        }

        urls = parsed
        durationsMs = durations
        scheduleStartMs = start
        currentIndex = -1
        scheduleRunning = true

        saveSettings()

        startButton.isEnabled = false
        stopButton.isEnabled = true
        setInputsEnabled(false)
        closeDrawer()

        handler.removeCallbacks(scheduleTask)
        handler.removeCallbacks(refreshTask)
        scheduleTask.run()
        handler.postDelayed(refreshTask, TimeUnit.SECONDS.toMillis(refreshSeconds))
    }

    private fun parseStartTime(value: String): Long? {
        val parts = value.split(":")
        if (parts.size != 2) return null
        val hour = parts[0].toIntOrNull() ?: return null
        val minute = parts[1].toIntOrNull() ?: return null
        if (hour !in 0..23 || minute !in 0..59) return null

        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    private fun loadUrlInAllPages(url: String) {
        browsers.forEach { it.loadUrl(url) }
    }

    private fun finishSchedule() {
        scheduleRunning = false
        handler.removeCallbacks(scheduleTask)
        handler.removeCallbacks(refreshTask)
        statusText.text = "Schedule complete"
        countdownText.text = "كل الروابط خلصت"
        startButton.isEnabled = true
        stopButton.isEnabled = false
        setInputsEnabled(true)
    }

    private fun stopSchedule() {
        scheduleRunning = false
        handler.removeCallbacks(scheduleTask)
        handler.removeCallbacks(refreshTask)
        if (::statusText.isInitialized) {
            statusText.text = "Stopped"
            countdownText.text = "تم إيقاف الجدولة"
            startButton.isEnabled = true
            stopButton.isEnabled = false
            setInputsEnabled(true)
        }
    }

    private fun setInputsEnabled(enabled: Boolean) {
        linkInputs.forEach { it.isEnabled = enabled }
        durationInputs.forEach { it.isEnabled = enabled }
        startTimeInput.isEnabled = enabled && !nowCheck.isChecked
        nowCheck.isEnabled = enabled
        refreshInput.isEnabled = enabled
    }

    private fun openDrawer() {
        drawer.visibility = View.VISIBLE
        drawerDim.visibility = View.VISIBLE
        hamburger.visibility = View.GONE
    }

    private fun closeDrawer() {
        if (::drawer.isInitialized) {
            drawer.visibility = View.GONE
            drawerDim.visibility = View.GONE
            hamburger.visibility = View.VISIBLE
        }
    }

    private fun restoreSettings() {
        val prefs = getSharedPreferences("quad_settings", MODE_PRIVATE)
        for (i in 0 until 10) {
            linkInputs[i].setText(prefs.getString("url_$i", ""))
            durationInputs[i].setText(prefs.getString("duration_$i", "90"))
        }
        refreshInput.setText(prefs.getString("refresh", "30"))
        startTimeInput.setText(prefs.getString("start", "13:30"))
        nowCheck.isChecked = prefs.getBoolean("now", true)
        startTimeInput.isEnabled = !nowCheck.isChecked
    }

    private fun saveSettings() {
        val prefs = getSharedPreferences("quad_settings", MODE_PRIVATE).edit()
        for (i in 0 until 10) {
            prefs.putString("url_$i", linkInputs[i].text.toString())
            prefs.putString("duration_$i", durationInputs[i].text.toString())
        }
        prefs.putString("refresh", refreshInput.text.toString())
        prefs.putString("start", startTimeInput.text.toString())
        prefs.putBoolean("now", nowCheck.isChecked)
        prefs.apply()
    }

    private fun normalizeUrl(raw: String): String =
        if (raw.startsWith("http://") || raw.startsWith("https://")) raw
        else "https://$raw"

    private fun formatDuration(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%02d:%02d:%02d".format(h, m, s)
        else "%02d:%02d".format(m, s)
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusDp.dp().toFloat()
        }

    private fun roundedBorder(): GradientDrawable =
        GradientDrawable().apply {
            setColor(Color.rgb(247, 248, 250))
            setStroke(1.dp(), Color.rgb(210, 216, 222))
            cornerRadius = 10.dp().toFloat()
        }

    private fun divider(): View =
        View(this).apply {
            setBackgroundColor(Color.rgb(225, 228, 232))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1.dp()
            ).apply {
                topMargin = 14.dp()
                bottomMargin = 14.dp()
            }
        }

    private fun Int.dp(): Int =
        (this * resources.displayMetrics.density).toInt()

    override fun onBackPressed() {
        if (::drawer.isInitialized && drawer.visibility == View.VISIBLE) {
            closeDrawer()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        scheduleRunning = false
        handler.removeCallbacksAndMessages(null)
        browsers.forEach {
            it.stopLoading()
            it.destroy()
        }
        browsers.clear()
        super.onDestroy()
    }
}
