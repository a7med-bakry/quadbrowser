# Quad Browser — GitHub APK Build Ready

## البناء من الموبايل باستخدام GitHub Actions

1. ارفع محتويات هذا المجلد إلى Repository على GitHub.
2. تأكد من وجود:
   `.github/workflows/build-apk.yml`
3. افتح تبويب **Actions**.
4. اختر **Build Android APK**.
5. اضغط **Run workflow** أو ادفع Commit جديد إلى `main`.
6. بعد انتهاء البناء افتح الـworkflow ثم **Artifacts**.
7. حمّل `QuadBrowser-APK` وستجد داخله `app-debug.apk`.

## النسخة الحالية
- 8 WebViews في تخطيط 2×4.
- حتى 10 روابط بمدة مستقلة.
- تبديل صارم بين الروابط مع تفريغ الرابط السابق قبل تحميل التالي.
- 3 أوضاع بيانات، كل وضع 25 دقيقة:
  1. عادي
  2. توفير البيانات
  3. توفير البيانات الأقصى
- Firebase مهيأ للمشروع عبر `google-services.json` وGoogle Services Gradle plugin.
