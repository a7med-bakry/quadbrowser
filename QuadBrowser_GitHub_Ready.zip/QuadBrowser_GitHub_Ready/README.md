# Quad Browser — Android

تطبيق Android يعرض الروابط المجدولة على 8 صفحات WebView في شاشة واحدة.

## المزايا الحالية
- 8 صفحات WebView في وضع عمودي 2×4.
- إدخال حتى 10 روابط، مع مدة مستقلة لكل رابط.
- تشغيل تلقائي للروابط بالتتابع مع عداد للرابط الحالي.
- عند انتهاء مدة الرابط يتم إيقاف/تفريغ الرابط السابق من صفحات WebView قبل تحميل الرابط التالي، مع طبقات تحقق إضافية لمنع بقاء الرابط القديم.
- تحديث الصفحات كل عدد ثوانٍ تحدده.
- أزرار ابدأ / إيقاف مؤقت / استئناف / إيقاف.
- 3 أوضاع بيانات: **عادي**، **توفير البيانات**، **توفير البيانات الأقصى**.
- كل وضع يستمر 25 دقيقة ثم ينتقل للتالي بالتتابع.
- استيراد وتصدير الروابط والمدة كملف نصي.
- JavaScript وDOM Storage مفعّلان للمواقع الحديثة.
- إعدادات Firebase مضافة للمشروع.

## ملاحظات
بعض المواقع تمنع WebView أو التحديث المتكرر أو تتطلب تسجيل دخول/تحقق أمني. التطبيق لا يتجاوز هذه القيود.


## Firebase login and shared links

The app now includes lightweight email/password account creation and login, cloud publishing of link sets, and importing link sets shared by other authenticated users.

Before using cloud sharing, enable **Authentication → Sign-in method → Email/Password** in Firebase Console and create a Firestore database. The included `firestore.rules` restricts writes/deletes to the owner while allowing authenticated users to read published link sets. Deploy the rules from a machine with Firebase CLI using `firebase deploy --only firestore:rules`.

The top mode button cycles **عادي → توفير البيانات → توفير البيانات الأقصى**. Automatic rotation remains 25 minutes per mode; manually changing the mode starts a fresh 25-minute mode interval.
