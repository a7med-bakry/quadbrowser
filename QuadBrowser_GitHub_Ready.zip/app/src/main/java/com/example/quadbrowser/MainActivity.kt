package com.example.quadbrowser

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val browsers = ArrayList<WebView>()
    private lateinit var urlInput: EditText
    private lateinit var secondsInput: EditText
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private var running = false

    private val refreshTask = object : Runnable {
        override fun run() {
            if (!running) return
            browsers.forEach { it.reload() }
            handler.postDelayed(this, getIntervalMs())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF111111.toInt())
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(10)
        }

        urlInput = EditText(this).apply {
            hint = "Website URL"
            setSingleLine(true)
            setText("https://example.com")
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFAAAAAA.toInt())
            setBackgroundColor(0xFF292929.toInt())
            setPadding(14)
        }

        secondsInput = EditText(this).apply {
            hint = "Seconds"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText("10")
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFAAAAAA.toInt())
            setBackgroundColor(0xFF292929.toInt())
            setPadding(14)
        }

        startButton = Button(this).apply {
            text = "START"
            setOnClickListener { startRefreshing() }
        }

        stopButton = Button(this).apply {
            text = "STOP"
            isEnabled = false
            setOnClickListener { stopRefreshing() }
        }

        controls.addView(urlInput, LinearLayout.LayoutParams(0, 56.dp(), 1f))
        controls.addView(space(8))
        controls.addView(secondsInput, LinearLayout.LayoutParams(90.dp(), 56.dp()))
        controls.addView(space(8))
        controls.addView(startButton, LinearLayout.LayoutParams(100.dp(), 56.dp()))
        controls.addView(space(4))
        controls.addView(stopButton, LinearLayout.LayoutParams(90.dp(), 56.dp()))
        root.addView(controls)

        val grid = GridLayout(this).apply {
            columnCount = 2
            rowCount = 2
            useDefaultMargins = false
        }

        repeat(4) {
            val web = createWebView()
            browsers.add(web)
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = 0
                columnSpec = GridLayout.spec(it % 2, 1, 1f)
                rowSpec = GridLayout.spec(it / 2, 1, 1f)
                setMargins(2, 2, 2, 2)
            }
            grid.addView(web, params)
        }

        root.addView(grid, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        return WebView(this).apply {
            setBackgroundColor(0xFFFFFFFF.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.userAgentString = WebSettings.getDefaultUserAgent(this@MainActivity)

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    view.loadUrl(request.url.toString())
                    return true
                }
                override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                }
            }
            webChromeClient = WebChromeClient()
        }
    }

    private fun startRefreshing() {
        val url = normalizeUrl(urlInput.text.toString())
        if (url.isBlank()) {
            Toast.makeText(this, "Enter a website URL", Toast.LENGTH_SHORT).show()
            return
        }
        val seconds = getSeconds()
        if (seconds < 1) {
            Toast.makeText(this, "Seconds must be at least 1", Toast.LENGTH_SHORT).show()
            return
        }

        browsers.forEach { it.loadUrl(url) }
        running = true
        startButton.isEnabled = false
        stopButton.isEnabled = true
        urlInput.isEnabled = false
        secondsInput.isEnabled = false

        handler.removeCallbacks(refreshTask)
        handler.postDelayed(refreshTask, seconds * 1000L)
    }

    private fun stopRefreshing() {
        running = false
        handler.removeCallbacks(refreshTask)
        startButton.isEnabled = true
        stopButton.isEnabled = false
        urlInput.isEnabled = true
        secondsInput.isEnabled = true
    }

    private fun getSeconds(): Long =
        secondsInput.text.toString().trim().toLongOrNull() ?: 10L

    private fun getIntervalMs(): Long =
        (getSeconds().coerceAtLeast(1L)) * 1000L

    private fun normalizeUrl(raw: String): String {
        val value = raw.trim()
        if (value.startsWith("http://") || value.startsWith("https://")) return value
        return "https://$value"
    }

    private fun space(dp: Int): Space =
        Space(this).apply { minimumWidth = dp.dp() }

    private fun Int.dp(): Int =
        (this * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        stopRefreshing()
        browsers.forEach {
            it.stopLoading()
            it.destroy()
        }
        browsers.clear()
        super.onDestroy()
    }
}
