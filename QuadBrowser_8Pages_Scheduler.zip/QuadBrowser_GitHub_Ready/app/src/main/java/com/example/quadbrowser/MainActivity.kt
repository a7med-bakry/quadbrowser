package com.example.quadbrowser

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val browsers = ArrayList<WebView>()
    private lateinit var linksInput: EditText
    private lateinit var startTimeInput: EditText
    private lateinit var durationInput: EditText
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var statusText: TextView
    private lateinit var countdownText: TextView

    private var scheduleRunning = false
    private var scheduleStartMs = 0L
    private var slotDurationMs = TimeUnit.MINUTES.toMillis(90)
    private var urls = emptyList<String>()

    private val schedulerTask = object : Runnable {
        override fun run() {
            if (!scheduleRunning) return

            val now = System.currentTimeMillis()
            if (now < scheduleStartMs) {
                updateCountdown(scheduleStartMs - now, "Starts in")
                handler.postDelayed(this, 1000L)
                return
            }

            val elapsed = now - scheduleStartMs
            val index = (elapsed / slotDurationMs).toInt()

            if (index >= urls.size) {
                finishSchedule()
                return
            }

            val slotStart = scheduleStartMs + index * slotDurationMs
            val remaining = slotStart + slotDurationMs - now

            // Load only when we enter a new time slot.
            if (lastLoadedIndex != index) {
                lastLoadedIndex = index
                loadUrlInAllPages(urls[index])
                statusText.text = "Active link ${index + 1} of ${urls.size}"
            }

            updateCountdown(remaining, "Time left")
            handler.postDelayed(this, 1000L)
        }
    }

    private var lastLoadedIndex = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF3F5F7.toInt())
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12.dp())
            setBackgroundColor(0xFFFFFFFF.toInt())
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val title = TextView(this).apply {
            text = "Quad Browser"
            textSize = 21f
            setTextColor(0xFF17202A.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        titleRow.addView(title, LinearLayout.LayoutParams(0, 44.dp(), 1f))

        statusText = TextView(this).apply {
            text = "Ready"
            textSize = 13f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(0xFF607080.toInt())
        }
        titleRow.addView(statusText, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, 44.dp()
        ))

        topBar.addView(titleRow)

        val linksHint = TextView(this).apply {
            text = "Links — one URL per line (up to 10)"
            textSize = 13f
            setTextColor(0xFF607080.toInt())
            setPadding(0, 4.dp(), 0, 4.dp())
        }
        topBar.addView(linksHint)

        linksInput = EditText(this).apply {
            hint = "https://example.com\nhttps://example.org"
            setTextSize(14f)
            gravity = Gravity.TOP or Gravity.START
            minLines = 2
            maxLines = 3
            setPadding(12.dp())
            setTextColor(0xFF17202A.toInt())
            setHintTextColor(0xFF9AA6B2.toInt())
            setBackgroundColor(0xFFF1F4F7.toInt())
        }
        topBar.addView(linksInput, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 72.dp()
        ))

        val scheduleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        startTimeInput = EditText(this).apply {
            hint = "Start 13:30"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_DATETIME
            setText("13:30")
            setPadding(10.dp())
            setTextColor(0xFF17202A.toInt())
            setBackgroundColor(0xFFF1F4F7.toInt())
        }

        durationInput = EditText(this).apply {
            hint = "Minutes"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText("90")
            setPadding(10.dp())
            setTextColor(0xFF17202A.toInt())
            setBackgroundColor(0xFFF1F4F7.toInt())
        }

        startButton = Button(this).apply {
            text = "START"
            setOnClickListener { startSchedule() }
        }

        stopButton = Button(this).apply {
            text = "STOP"
            isEnabled = false
            setOnClickListener { stopSchedule() }
        }

        scheduleRow.addView(startTimeInput, LinearLayout.LayoutParams(0, 52.dp(), 1f))
        scheduleRow.addView(space(6))
        scheduleRow.addView(durationInput, LinearLayout.LayoutParams(0, 52.dp(), .65f))
        scheduleRow.addView(space(6))
        scheduleRow.addView(startButton, LinearLayout.LayoutParams(0, 52.dp(), .8f))
        scheduleRow.addView(space(4))
        scheduleRow.addView(stopButton, LinearLayout.LayoutParams(0, 52.dp(), .7f))
        topBar.addView(scheduleRow)

        countdownText = TextView(this).apply {
            text = "Enter links and press START"
            textSize = 13f
            setTextColor(0xFF607080.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 5.dp(), 0, 0)
        }
        topBar.addView(countdownText)

        root.addView(topBar)

        // Browser-style address/status strip.
        val browserBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8.dp(), 4.dp(), 8.dp(), 4.dp())
            setBackgroundColor(0xFFE8EDF2.toInt())
        }
        val browserLabel = TextView(this).apply {
            text = "●  8 pages"
            textSize = 12f
            setTextColor(0xFF455A64.toInt())
        }
        browserBar.addView(browserLabel, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, 34.dp()
        ))
        root.addView(browserBar)

        val grid = GridLayout(this).apply {
            columnCount = 4
            rowCount = 2
            useDefaultMargins = false
            setPadding(4.dp())
        }

        repeat(8) { index ->
            val web = createWebView(index)
            browsers.add(web)
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = 0
                columnSpec = GridLayout.spec(index % 4, 1, 1f)
                rowSpec = GridLayout.spec(index / 4, 1, 1f)
                setMargins(3.dp(), 3.dp(), 3.dp(), 3.dp())
            }
            grid.addView(web, params)
        }

        root.addView(grid, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(index: Int): WebView {
        return WebView(this).apply {
            setBackgroundColor(0xFFFFFFFF.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.userAgentString = WebSettings.getDefaultUserAgent(this@MainActivity)

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    view.loadUrl(request.url.toString())
                    return true
                }

                override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    view.contentDescription = "Page ${index + 1}: $url"
                }
            }
            webChromeClient = WebChromeClient()
        }
    }

    private fun startSchedule() {
        val parsedUrls = linksInput.text.toString()
            .lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(10)
            .map { normalizeUrl(it) }

        if (parsedUrls.isEmpty()) {
            Toast.makeText(this, "Enter at least one URL", Toast.LENGTH_SHORT).show()
            return
        }

        val minutes = durationInput.text.toString().trim().toLongOrNull() ?: 90L
        if (minutes < 1) {
            Toast.makeText(this, "Duration must be at least 1 minute", Toast.LENGTH_SHORT).show()
            return
        }

        val start = parseStartTime(startTimeInput.text.toString().trim())
        if (start == null) {
            Toast.makeText(this, "Use start time like 13:30", Toast.LENGTH_SHORT).show()
            return
        }

        urls = parsedUrls
        slotDurationMs = TimeUnit.MINUTES.toMillis(minutes)
        scheduleStartMs = start
        lastLoadedIndex = -1
        scheduleRunning = true

        startButton.isEnabled = false
        stopButton.isEnabled = true
        linksInput.isEnabled = false
        startTimeInput.isEnabled = false
        durationInput.isEnabled = false

        handler.removeCallbacks(schedulerTask)
        schedulerTask.run()
    }

    private fun parseStartTime(value: String): Long? {
        val parts = value.split(":")
        if (parts.size != 2) return null
        val hour = parts[0].toIntOrNull() ?: return null
        val minute = parts[1].toIntOrNull() ?: return null
        if (hour !in 0..23 || minute !in 0..59) return null

        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, hour)
        cal.set(java.util.Calendar.MINUTE, minute)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)

        // If today's time already passed, schedule for tomorrow.
        if (cal.timeInMillis <= System.currentTimeMillis()) {
            cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    private fun loadUrlInAllPages(url: String) {
        browsers.forEach { it.loadUrl(url) }
    }

    private fun updateCountdown(ms: Long, label: String) {
        val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        countdownText.text = "$label  %02d:%02d:%02d".format(hours, minutes, seconds)
    }

    private fun finishSchedule() {
        scheduleRunning = false
        handler.removeCallbacks(schedulerTask)
        statusText.text = "Schedule complete"
        countdownText.text = "All ${urls.size} links completed"
        startButton.isEnabled = true
        stopButton.isEnabled = false
        linksInput.isEnabled = true
        startTimeInput.isEnabled = true
        durationInput.isEnabled = true
    }

    private fun stopSchedule() {
        scheduleRunning = false
        handler.removeCallbacks(schedulerTask)
        statusText.text = "Stopped"
        countdownText.text = "Schedule stopped"
        startButton.isEnabled = true
        stopButton.isEnabled = false
        linksInput.isEnabled = true
        startTimeInput.isEnabled = true
        durationInput.isEnabled = true
    }

    private fun normalizeUrl(raw: String): String {
        val value = raw.trim()
        if (value.startsWith("http://") || value.startsWith("https://")) return value
        return "https://$value"
    }

    private fun space(dp: Int): Space =
        Space(this).apply { minimumWidth = dp.dp() }

    private fun Int.dp(): Int =
        (this * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        stopSchedule()
        browsers.forEach {
            it.stopLoading()
            it.destroy()
        }
        browsers.clear()
        super.onDestroy()
    }
}
