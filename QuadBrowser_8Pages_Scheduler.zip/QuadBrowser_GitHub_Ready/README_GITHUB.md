# Quad Browser — GitHub APK Build Ready

هذا المشروع جاهز للرفع إلى GitHub وبناء APK من خلال GitHub Actions بدون كمبيوتر.

## طريقة البناء من الموبايل

1. أنشئ Repository جديد على GitHub.
2. ارفع كل محتويات هذا المجلد إلى الـRepository.
3. تأكد أن الملف موجود في:
   `.github/workflows/build-apk.yml`
4. افتح تبويب **Actions** في الـRepository.
5. اختر **Build Android APK**.
6. اضغط **Run workflow**.
7. بعد انتهاء البناء بنجاح افتح نتيجة الـworkflow.
8. من قسم **Artifacts** حمّل:
   `QuadBrowser-APK`
9. فك ضغط ملف الـArtifact وستجد:
   `app-debug.apk`
10. افتح APK على هاتف Android وثبته.

## ملاحظات
- الـAPK الناتج Debug APK ومناسب للاختبار والتثبيت المباشر.
- التطبيق يعرض نفس الرابط في 4 WebViews (2×2).
- يمكن تحديد عدد الثواني بين عمليات التحديث.
- بعض المواقع قد تمنع WebView أو التحديث المتكرر أو تتطلب تسجيل دخول/تحقق أمني.

GitHub Actions يسمح بتشغيل workflows على خوادم GitHub، ويمكن حفظ ملفات البناء كـArtifacts.
